# Graded Assignment 2 - (May 2025 - English I)

> The due date for submitting this assignment has passed.
Due on 2025-06-18, 23:59 IST.
You may submit any number of times before the due date. The final submission will be considered for grading.

> **Last Submitted:** You have last submitted on: 2025-06-11, 21:09 IST

---

### Question 1

Identify the part of speech of the underlined word.  She was honoured for her courage.
- [ ] Adjective
- [ ] Adverb
- [x] Noun
- [ ] Verb

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Noun

---

### Question 2

Identify the part of speech of the underlined word.  Catherine was worried about her work.
- [ ] Abstract noun
- [x] Verb
- [ ] Noun
- [ ] Adverb

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Verb

---

### Question 3

Select the correct pronoun.   The bus came to a halt by \_\_\_\_\_\_\_\_\_.
- [ ] Himself
- [x] Itself

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Itself

---

### Question 4

Select the appropriate option.  Golconda Fort is the \_\_\_\_\_\_\_\_\_ site I saw in Hyderabad.
- [ ] Amazing
- [ ] More amazing
- [x] Most amazing
- [ ] As amazing

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Most amazing

---

### Question 5

Identify the part of speech of the underlined word.  _The_ _red balloon floated away._
- [ ] Adverb
- [x] Adjective
- [ ] Verb
- [ ] Noun

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Adjective

---

### Question 6

Identify the adverb in the following sentence: 

_She was softly singing to the baby._
- [ ] Baby
- [ ] Singing
- [x] Softly
- [ ] She

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Softly

---

### Question 7

Choose the appropriate option. 

There is \_\_\_\_\_\_ book on the desk.
- [x] A
- [ ] An
- [ ] The
- [ ] No article

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* A

---

### Question 8

Choose the appropriate option. 

The doctor gave me a prescription \_\_\_\_\_\_\_\_ my headache.
- [ ] With
- [ ] At
- [ ] To
- [x] For

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* For

---

### Question 9

Choose the appropriate option. 

Both Ajay \_\_\_\_\_\_\_ Sanjay are intelligent.
- [ ] Nor
- [ ] Or
- [x] And
- [ ] Since

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* And

---

### Question 10

\_\_\_ coffee taster had his tongue insured for 10 million pounds.
- [ ] An
- [x] A

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* A

---

### Question 11

---

