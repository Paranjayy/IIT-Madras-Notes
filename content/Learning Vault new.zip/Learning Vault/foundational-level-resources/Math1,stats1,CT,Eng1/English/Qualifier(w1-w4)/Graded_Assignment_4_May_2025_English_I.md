# Graded Assignment 4 - (May 2025 - English I)

> The due date for submitting this assignment has passed.
Due on 2025-07-02, 23:59 IST.
You may submit any number of times before the due date. The final submission will be considered for grading.

> **Last Submitted:** You have last submitted on: 2025-06-24, 22:07 IST

---

### Question 1

So far as the ultimate goal is concerned I think none of us need have any apprehensions None of us need have any doubt
- [x] So far/ as the ultimate goal is concerned/ I think none of us/ need have any apprehensions//None of us need have/ any doubt//
- [ ] So far as the/ ultimate goal/ is concerned/ I think none of us need/ have any apprehensions None/ of us need have any doubt//
- [ ] So far/ as the ultimate/ goal is concerned/ I think none of us/ need have any apprehensions// None of us need/ have any doubt//

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* So far/ as the ultimate goal is concerned/ I think none of us/ need have any apprehensions//None of us need have/ any doubt//

---

### Question 2

Our difficulty is how to make the heterogeneous mass that we have today take a decision in common and march in a cooperative way on that road which is bound to lead us to unity
- [ ] Our difficulty/ is how to make the/ heterogeneous mass that/ we have today take/ a decision in common/ and march/ in a cooperative way on that road which is/ bound to lead us to unity//
- [x] Our difficulty is/ how to make/ the heterogeneous mass/ that we have today/ take a decision/ in common/ and march in a cooperative way/ on that road/ which is bound to lead us to unity//
- [ ] Our difficulty is/ how to/ make the heterogeneous mass/ that/ we have today/ take a decision/ in common and/ march in a cooperative way on that road/ which is bound to lead us to unity//

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Our difficulty is/ how to make/ the heterogeneous mass/ that we have today/ take a decision/ in common/ and march in a cooperative way/ on that road/ which is bound to lead us to unity//

---

### Question 3

Our difficulty is not with regard to the ultimate our difficulty is with regard to the beginning
- [ ] Our difficulty/ is not/ with regard to the ultimate/ our difficulty/ is with regard to the beginning//
- [ ] Our difficulty is/ not with regard to/ the ultimate our difficulty/ is with regard to the beginning//
- [x] Our difficulty is not with regard to the ultimate/ our difficulty is with regard to the beginning//

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Our difficulty is not with regard to the ultimate/ our difficulty is with regard to the beginning//

---

### Question 4

Mr. Chairman therefore I should have thought that in order to make a start in order to induce every party every section in this country it would be the act of greatest statesmanship for the majority party even to make a concession to the prejudices of people who are not prepared to march together and it is for that that I propose to make this appeal
- [ ] Mr. Chairman/ therefore I should have thought that/ in order to make/ a start in order to induce/ every party every section/ in this country it would be/ the act of greatest statesmanship for the majority party/ even to make a concession/ to the prejudices of people who are not prepared to march together and it is for that that I propose to make this appeal//
- [x] Mr. Chairman therefore/ I should have thought/ that in order to make a start/ in order to induce/ every/ party/ every section/ in this country/ it would be the act of greatest statesmanship/ for the majority party/ even to make a concession to the prejudices/ of people who are not prepared to march together/ and it is for that/ that I propose to make this appeal//
- [ ] Mr. Chairman therefore/ I should have thought that/ in order to make a start/ in order to induce/ every party/ every section/ in this country/ it would be the act of greatest statesmanship/ for the majority party/ even to make a concession to the prejudices/ of people who are not prepared to march together and/ it is for that that I propose to make this appeal//

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Mr. Chairman therefore/ I should have thought/ that in order to make a start/ in order to induce/ every/ party/ every section/ in this country/ it would be the act of greatest statesmanship/ for the majority party/ even to make a concession to the prejudices/ of people who are not prepared to march together/ and it is for that/ that I propose to make this appeal//

---

### Question 5

Let us leave aside slogans let us leave aside words which frighten people
- [ ] Let us leave/ aside slogans/ let us leave/ aside words which frighten people//
- [ ] Let us leave aside slogans/ let us leave/ aside words which frighten people//
- [x] Let us leave aside slogans/ let us leave aside words which frighten people//

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Let us leave aside slogans/ let us leave aside words which frighten people//

---

### Question 6

Mark the appropriate response.  
 Deepthi is not here. Could you please \_\_\_\_\_\_.
- [ ] Speak up
- [ ] Hang up
- [x] Hang on
- [ ] Ring her later


**Accepted Answers:**

* Ring her later

---

### Question 7

When someone says “_Your voice is echoing_” it becomes evident the voice is resurfacing and hence the tele-conversation is not clear.
- [x] True
- [ ] False

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* True

---

### Question 8

The phrase ‘_speak up_’ means to tone down the voice.
- [ ] True
- [x] False

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* False

---

### Question 9

Geetha, while speaking to Mary (on the phone) hears vibrating noise. Choose the best appropriate sentence that Geeta should use to convey the problem.
- [ ] Your voice is echoing.
- [x] Your voice is jarring.
- [ ] You have to speak up.
- [ ] You are not audible.

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Your voice is jarring.

---

### Question 10

The phrase _‘pick up’_ (in the context of a telephonic conversation) means to answer the call.
- [x] True
- [ ] False

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* True

---

