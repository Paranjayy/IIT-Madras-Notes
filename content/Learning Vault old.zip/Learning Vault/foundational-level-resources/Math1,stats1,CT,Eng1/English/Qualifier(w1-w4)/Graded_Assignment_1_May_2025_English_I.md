# Graded Assignment 1 - (May 2025 - English I)

> The due date for submitting this assignment has passed.
Due on 2025-06-11, 23:59 IST.
You may submit any number of times before the due date. The final submission will be considered for grading.

> **Last Submitted:** You have last submitted on: 2025-06-11, 21:06 IST

---

### Question 1

Which among the following words carry the sound /z/ in them?
- [x] (a) Xerox
- [ ] (b) Trips
- [ ] (c) Both a and b

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* (a) Xerox

---

### Question 2

Which among the following words carry the sound ‘sh’?
- [ ] (a) Charade
- [ ] (b) Special
- [ ] (c) Sebaceous
- [ ] (d) Only a and b
- [x] (e) All a, b, and c

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* (e) All a, b, and c

---

### Question 3

Which among the following carry the short vowel /u/?
- [ ] (a) Should
- [ ] (b) Book
- [ ] (c) Truth
- [x] (d) Only a and b
- [ ] (e) Only a and c

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* (d) Only a and b

---

### Question 4

Answer whether true or false.  
  
/w/ and /y/ are monophthongs.
- [ ] True
- [x] False

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* False

---

### Question 5

Answer whether true or false.  
  
Semi-vowels are syllabic in nature.
- [ ] True
- [x] False

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* False

---

### Question 6

What do you hear at 1:23?
- [x] Saws
- [ ] Shows

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Saws

---

### Question 7

What do you hear at 1:41?
- [ ] Horse
- [x] Hose

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Hose

---

### Question 8

What do you hear at 2:09?
- [ ] Sons
- [x] Sans

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Sans

---

### Question 9

The word _‘oblivion’_ has \_\_\_\_.
- [x] All short vowels
- [ ] One long vowel

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* All short vowels

---

### Question 10

The word _‘pantaloon’_ has \_\_\_\_\_.
- [ ] Two long vowels
- [x] Only one long vowel

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Only one long vowel

---

