# Graded Assignment 3 - (May 2025 - English I)

> The due date for submitting this assignment has passed.
Due on 2025-06-25, 23:59 IST.
You may submit any number of times before the due date. The final submission will be considered for grading.

> **Last Submitted:** You have last submitted on: 2025-06-24, 22:01 IST

---

### Question 1

Perseverance
- [x] Dedication
- [ ] Sloth

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Dedication

---

### Question 2

Sacrosanct
- [ ] Earthly
- [x] Holy

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Holy

---

### Question 3

Choose an appropriate prefix that gives the antonym of ‘apologetic’.
- [ ] Dis-
- [ ] Mis-
- [x] Un-
- [ ] Non-

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Un-

---

### Question 4

 Choose the appropriate option. 

            Those bright pink football boots really \_\_\_\_\_\_\_\_\_\_\_.
- [ ] Stand down
- [ ] Stand up
- [x] Stand out
- [ ] Stand aside

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Stand out

---

### Question 5

 Choose the appropriate option. 

     Let’s \_\_\_\_\_\_\_ the old toy. We don’t need it.
- [ ] Throw in
- [x] Throw away
- [ ] Throw up
- [ ] Throw on

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Throw away

---

### Question 6

Choose the correct option. 

      I think I  \_\_\_\_\_\_\_\_ have failed the exam, but I’m not sure.
- [ ] Shall
- [x] Might

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Might

---

### Question 7

Choose the correct option. 

       You\_\_\_\_\_\_\_\_\_\_ help me!
- [ ] Should to
- [x] Have to

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* Have to

---

### Question 8

Getting a second wind

      Meaning: Having energy again after being tired.
- [x] True.
- [ ] False.

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* True.

---

### Question 9

Going on a wild goose chase

Meaning: Taking credit for someone else's achievements.
- [ ] True.
- [x] False.

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* False.

---

### Question 10

The elephant in the room

Meaning: Everyone gets their chance to do something big.
- [ ] True.
- [x] False.

**Status:** Yes, the answer is correct.
**Score: 1**

**Accepted Answers:**

* False.

---

